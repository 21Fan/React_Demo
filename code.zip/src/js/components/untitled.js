import React from 'react';

export default class PCHeader extends React.Component{
	render(){
		return(
        
            <div></div>
		);
	};
}
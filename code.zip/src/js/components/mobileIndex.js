import React from 'react';
import MobileHeader from './mobileHeader';

export default class MobileIndex extends React.Component{
	render(){
		return(
        <div>
            <MobileHeader></MobileHeader>
        </div>
		
		);
	};
}